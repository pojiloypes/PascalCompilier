﻿#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include <windows.h>

#include "SyntacticSemanticAnalyzer.h"

using namespace std;


void lexerMain()
{
    LexicalAnalyzer* lexer = new LexicalAnalyzer("pascalProgram.txt");
    ofstream fout = ofstream("ProgramCodes.txt");

    while (!lexer->checkEof())
    {
        lexer->nextSym();
        if (!lexer->checkEof())
        {
            int code = lexer->getSymbolCode();

            if (code != 0) fout << code << endl;
        }

        //cout << newChar;
    }
    fout.close();
    lexer->~LexicalAnalyzer();
}

int main()
{
    //setlocale(LC_ALL, "Russian");
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    SyntacticSemanticAnalyzer* syntaxer = new SyntacticSemanticAnalyzer("pascalProgram.txt");
    
    syntaxer->programme();
    syntaxer->~SyntacticSemanticAnalyzer();
}

