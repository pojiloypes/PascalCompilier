#include "IdentifiersTable.h"

IdentifierClass::IdentifierClass(string name, int identType)
{
	this->name = name;
	this->identType = identType;
	if (identType != Identifiers::ident) parametrs = vector<IdentifierClass*>();
}

IdentifierClass::IdentifierClass(string name, int dataType, int identType)
{
	this->name = name;
	this->dataType = dataType;
	this->identType = identType;
	if (identType != Identifiers::ident) parametrs = vector<IdentifierClass*>();
}

void IdentifierClass::addParametr(IdentifierClass* newParam) { parametrs.push_back(newParam); }

string IdentifierClass::getName() { return name; }

int IdentifierClass::getDataType() { return dataType; }

int IdentifierClass::getIdentType() { return identType; }

vector<IdentifierClass*> IdentifierClass::getParametrs() { return parametrs; }

void IdentifierClass::setDataType(int dt) { this->dataType = dt; }


//class Node
//{
//
//};
//
//class ScopeNode : public Node
//{
//	int height;
//	int sequenceNumber;
//	string name;
//	ScopeNode* parrent;
//	vector<ScopeNode*> chieldScopes;
//	vector<IdentifierNode*> chieldIdents;
//
//public:
//	ScopeNode(string name, ScopeNode* parrent)
//	{
//		this->name = name;
//		this->parrent = parrent;
//		chieldScopes = vector<ScopeNode*>();
//		chieldIdents = vector<IdentifierNode*>();
//		if (parrent != nullptr)
//		{
//			height = parrent->height+1;
//			sequenceNumber = parrent->chieldScopes.size() + parrent->chieldIdents.size();
//		}
//		else
//		{
//			height = 0;
//			sequenceNumber = 0;
//		}
//	}
//
//	void addChieldScope(ScopeNode* chield) { chieldScopes.push_back(chield); }
//
//	void addChieldIdent(IdentifierNode* chield) { chieldIdents.push_back(chield); }
//
//	int getHeight() { return height; }
//
//	vector<ScopeNode*> getScopes() { return chieldScopes; }
//
//	vector<IdentifierNode*> getIdents() { return chieldIdents; }
//};
//
//class IdentifierNode : public Node
//{
//string name;
//int dataType;
//	int identType; // 1 - proc, 2 - func, 3 - var
//	int height;
//	int sequenceNumber;
//	ScopeNode* parrent;
//	vector<IdentifierNode> parametrs;
//
//public:
//	IdentifierNode(string name, int dataType, int identType, ScopeNode* parrent)
//	{
//		this->name = name;
//		this->dataType = dataType;
//		this->identType = identType;
//		this->parrent = parrent;
//		if (identType != 3) parametrs = vector<IdentifierNode>();
//		if (parrent != nullptr)
//		{
//			height = parrent->getHeight()+1;
//			sequenceNumber = parrent->getScopes().size() + parrent->getIdents().size();
//		}
//		else
//		{
//			height = 0;
//			sequenceNumber = 0;
//		}
//	}
//	
//	ScopeNode* getParrent() { return parrent; }
//		
//	int getHeight() { return height; }
//
//	int getSeqNum() { return sequenceNumber; }
//
//	string getName() { return name; }
//};
//
//class IdentifiersTable
//{
//	map<string, IdentifierNode> table;
//
//	IdentifiersTable()
//	{
//		table = map<string, IdentifierNode>();
//	}
//
//	bool insert(IdentifierNode identNode)
//	{
//		bool res = false;
//		if (table.find(identNode.getName()) == table.end())
//		{
//			res = true;
//			table[identNode.getName()] = identNode;
//		}
//		return res;
//	}
//
//	bool checkSameScope(IdentifierNode* ch1, IdentifierNode* ch2)
//	{
//		bool res = false, endFlag = false;
//		ScopeNode *par1 = ch1->getParrent(), par2 = *ch2->getParrent();
//		if (par1 == par1)
//		{
//			if (ch1->getSeqNum() < ch2->getSeqNum()) res = true;
//			else endFlag = true;
//		}
//		else if (ch1->getHeight() == ch2->getHeight()) endFlag = true;
//		while (!endFlag && !res)
//		{
//			
//		}
//		
//		
//	}
//};