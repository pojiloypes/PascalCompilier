#include "TextPosition.h"

struct Error
{
public:
    int errorCode;
    TextPosition position;

    Error(TextPosition errorPos, int errorCode);
}; 
