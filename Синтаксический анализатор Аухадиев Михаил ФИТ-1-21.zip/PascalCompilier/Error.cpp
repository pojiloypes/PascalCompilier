#include "Error.h"


Error::Error(TextPosition errorPos, int errorCode)
{
    this->errorCode = errorCode;
    this->position = errorPos;
}
