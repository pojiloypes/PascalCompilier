class CharacterIdentifier
{
public:
    static bool isDigit(char ch);

    static bool isLetter(char ch);

    static int getCharCode(char ch);
};