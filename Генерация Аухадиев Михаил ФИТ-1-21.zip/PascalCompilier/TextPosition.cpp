#include "TextPosition.h"

TextPosition::TextPosition(int newLineNum, int newCharNum)
{
    lineNum = newLineNum;
    charNum = newCharNum;
}

