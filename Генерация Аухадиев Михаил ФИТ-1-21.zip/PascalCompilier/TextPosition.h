struct TextPosition
{
public:
    int lineNum;
    int charNum;

    TextPosition(int newLineNum = 0, int newCharNum = 0);
};
